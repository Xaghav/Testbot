```markdown
# BIRD Discord Bot — Python port

This repository contains a Python async port of the original BIRD Discord Bot.

Overview
- Language: Python (async)
- Discord library: discord.py
- HTTP client: aiohttp
- Database: SQLite via SQLAlchemy (async + aiosqlite)
- DTO parsing: pydantic
- Configuration: .env (python-dotenv)
- Logging: Python logging

High-level architecture

Mermaid flow (component-level):
```mermaid
flowchart LR
  A[Discord (discord.py)] --> B[OtherworldlyCommands Cog]
  B --> C[ClanService]
  C --> D[ClanCupClient (aiohttp)]
  B --> E[DropService]
  E --> F[OtherWorldlyDropRepo]
  F --> G[SQLite Database (aiosqlite)]
  B --> H[Logging]
  E --> H
  C --> H
```

Textual component summary
- Discord Bot (src/bot/runner.py)
  - Bootstraps the bot, initializes DB and services, registers commands.
- Commands / Cog (src/bot/cogs/otherworldly_commands.py)
  - Commands: ping, updateDB, updateDBUsingAppService, fetch
  - Interacts with services and repository.
- Clan client & service
  - src/clients/clan_cup.py (ClanCupClient) — low-level HTTP client (aiohttp).
  - src/services/clan_service.py (ClanService) — calls client and parses JSON into pydantic models.
- Database & repo
  - src/db/engine.py — creates async SQLAlchemy engine and session factory.
  - src/models/db_models.py — OtherWorldlyDrop ORM model.
  - src/db/repository.py — repository with add/get operations, uniqueness checks.
- Business service
  - src/services/drop_service.py — example service that uses repository logic to add/read drops.
- Models
  - src/models/api_models.py — pydantic DTOs (Clan, Skill, TopClans).
  - src/models/db_models.py — SQLAlchemy model (OtherWorldlyDrop).
- Logging
  - src/logger.py — central logging configuration.

Run / quickstart
1. Copy `.env.example` to `.env` and set DISCORD_TOKEN:
   ```
   DISCORD_TOKEN=your-bot-token
   DATABASE_PATH=./otherworldly.db
   BOT_PREFIX=!
   LOG_LEVEL=INFO
   ```
2. Install dependencies:
   ```
   python -m pip install -r requirements.txt
   ```
3. Run the bot:
   ```
   python -m src.bot.runner
   ```

Notes / troubleshooting
- The project uses an async SQLAlchemy engine with a SQLite file. The DB path can be changed with `DATABASE_PATH` in the environment.
- The ClanCup API is queried from the `ClanCupClient`. If you plan to run frequent requests, consider adding caching or rate-limiting.
- Secrets (Discord token) are not included. Use `.env` and GitHub Secrets for CI/deployment.

Files included (high level)
- src/bot/runner.py
- src/bot/cogs/otherworldly_commands.py
- src/clients/clan_cup.py
- src/services/clan_service.py
- src/services/drop_service.py
- src/models/api_models.py
- src/models/db_models.py
- src/db/engine.py
- src/db/repository.py
- src/logger.py
- requirements.txt, .env.example, tests/

If you want the diagram adjusted (different layout, more detail, sequence diagram instead of component-flow), tell me which style you prefer and I’ll update the README before pushing.
```