contents:
from discord.ext import commands
import logging
from src.services.api_service import ApiService
from src.services.app_service import AppService
from src.data.repository import OtherWorldlyDropRepo
from src.data.models import OtherWorldlyDrop
import uuid

logger = logging.getLogger("bird.cogs.gold_printer")


class ModuleGoldPrinter(commands.Cog):
    def __init__(self, bot: commands.Bot, api_service: ApiService, other_repo: OtherWorldlyDropRepo, app_service: AppService):
        self.bot = bot
        self._api_service = api_service
        self._app_service = app_service
        self._other_repo = other_repo

    @commands.command(name="ping")
    async def ping(self, ctx: commands.Context):
        await ctx.send("Pong!")

    @commands.command(name="updateDB")
    async def update_db(self, ctx: commands.Context):
        new_user = uuid.uuid4()
        add_user_drop = OtherWorldlyDrop("test", new_user, 0.0, 0.0, 0.0, 0, 0)
        await self._other_repo.add_other_worldly_drop(add_user_drop)
        await ctx.send("DB updated (attempted to add test user)")

    @commands.command(name="updateDBUsingAppService")
    async def update_db_using_app_service(self, ctx: commands.Context):
        await self._app_service.run_async()
        await ctx.send("Ran AppService")

    @commands.command(name="fetch")
    async def fetch(self, ctx: commands.Context):
        try:
            top_clans = await self._api_service.get_top_clans()
            if not top_clans:
                await ctx.send("No data returned from API.")
                return

            # Logging similar to C# original
            for skill in top_clans.topScoreClans:
                logger.info(f"objective: {skill.objective}, Objective: {skill.standings}")
                for standing in skill.standings:
                    logger.info(f"Clan Name: {standing.clanName}, Score: {standing.score}, Rank: {standing.rank}")

            await ctx.send("Fetched top clans (check logs for details).")
        except Exception as ex:
            logger.exception("Exception happened when trying to fetch the api")
            await ctx.send("Failed to get api results.")