contents:
from discord.ext import commands
import logging
from src.services.clan_service import ClanService
from src.services.drop_service import DropService
from src.db.repository import OtherWorldlyDropRepo
from src.models.db_models import OtherWorldlyDrop
import uuid

logger = logging.getLogger("bird.cogs.otherworldly")


class OtherworldlyCog(commands.Cog, name="Otherworldly"):
    def __init__(self, bot: commands.Bot, clan_service: ClanService, other_repo: OtherWorldlyDropRepo, drop_service: DropService):
        self.bot = bot
        self._clan_service = clan_service
        self._drop_service = drop_service
        self._other_repo = other_repo

    @commands.command(name="ping")
    async def ping(self, ctx: commands.Context):
        await ctx.send("Pong!")

    @commands.command(name="updateDB")
    async def update_db(self, ctx: commands.Context):
        new_user = uuid.uuid4()
        add_user_drop = OtherWorldlyDrop("test", new_user, 0.0, 0.0, 0.0, 0, 0)
        await self._other_repo.add_other_worldly_drop(add_user_drop)
        await ctx.send("DB updated (attempted to add test user)")

    @commands.command(name="updateDBUsingAppService")
    async def update_db_using_app_service(self, ctx: commands.Context):
        await self._drop_service.run_async()
        await ctx.send("Ran DropService")

    @commands.command(name="fetch")
    async def fetch(self, ctx: commands.Context):
        try:
            top_clans = await self._clan_service.get_top_clans()
            if not top_clans:
                await ctx.send("No data returned from API.")
                return

            for skill in top_clans.topScoreClans:
                logger.info(f"objective: {skill.objective}, Objective: {skill.standings}")
                for standing in skill.standings:
                    logger.info(f"Clan Name: {standing.clanName}, Score: {standing.score}, Rank: {standing.rank}")

            await ctx.send("Fetched top clans (check logs for details).")
        except Exception:
            logger.exception("Exception happened when trying to fetch the api")
            await ctx.send("Failed to get api results.")