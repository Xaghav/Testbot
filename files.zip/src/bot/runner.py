contents:
import os
import asyncio
from pathlib import Path
from dotenv import load_dotenv
import logging

import discord
from discord.ext import commands

from src.logger import configure_logging
from src.clients.clan_cup import ClanCupClient
from src.services.clan_service import ClanService
from src.services.drop_service import DropService
from src.db.engine import get_default_db_path, make_engine, make_session_factory, init_db
from src.db.repository import OtherWorldlyDropRepo
from src.bot.cogs.otherworldly import OtherworldlyCog

load_dotenv(dotenv_path=Path.cwd() / ".env")

TOKEN = os.getenv("DISCORD_TOKEN")
PREFIX = os.getenv("BOT_PREFIX", "!")
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()

configure_logging(LOG_LEVEL)
logger = logging.getLogger("bird.runner")


async def main():
    if not TOKEN:
        logger.error("DISCORD_TOKEN is not set in environment.")
        raise SystemExit("Missing DISCORD_TOKEN")

    db_path = os.environ.get("DATABASE_PATH", get_default_db_path())
    engine = make_engine(db_path)
    await init_db(engine)
    session_factory = make_session_factory(engine)

    # services
    clan_client = ClanCupClient()
    clan_service = ClanService(clan_client)
    other_repo = OtherWorldlyDropRepo(session_factory)
    drop_service = DropService(other_repo)

    intents = discord.Intents.default()
    intents.message_content = True
    intents.members = True

    bot = commands.Bot(command_prefix=PREFIX, intents=intents, help_command=None)

    # add the cog with constructed dependencies
    await bot.add_cog(OtherworldlyCog(bot, clan_service, other_repo, drop_service))

    @bot.event
    async def on_ready():
        logger.info(f"Logged in as {bot.user} (id: {bot.user.id})")
        logger.info("Bot is ready.")

    # Run the bot
    await bot.start(TOKEN)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Shutting down...")