contents:
import aiohttp
import logging
from typing import Optional

logger = logging.getLogger("bird.clients.clan_cup")


class ClanCupClient:
    """
    Async client for https://query.idleclans.com/api/ClanCup/top-clans/current
    """

    BASE_URL = "https://query.idleclans.com/api/ClanCup/top-clans/current"

    def __init__(self, session: Optional[aiohttp.ClientSession] = None):
        self._external_session = session is not None
        self._session = session or aiohttp.ClientSession()

    async def get_top_clans(self) -> str:
        try:
            params = {"gameMode": "Default"}
            async with self._session.get(self.BASE_URL, params=params) as resp:
                resp.raise_for_status()
                text = await resp.text()
                return text
        except Exception:
            logger.exception("Failed to fetch top clans from ClanCup API")
            raise

    async def close(self):
        if not self._external_session:
            await self._session.close()