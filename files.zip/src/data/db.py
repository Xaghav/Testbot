contents:
import os
from pathlib import Path
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from src.data.models import Base
import logging

logger = logging.getLogger("bird.data.db")


def get_default_db_path() -> str:
    # Default to working directory DB file like the C# app created in LocalAppData.
    # You can change this to a platform-specific path if desired.
    return os.environ.get("DATABASE_PATH", "./otherworldly.db")


def make_engine(db_path: str):
    # Async SQLite URL for SQLAlchemy
    url = f"sqlite+aiosqlite:///{db_path}"
    engine = create_async_engine(url, echo=False, future=True)
    return engine


def make_session_factory(engine):
    return sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


async def init_db(engine):
    # create tables
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("Database initialized / tables created.")