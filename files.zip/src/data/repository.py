contents:
from typing import List
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from src.data.models import OtherWorldlyDrop
import logging

logger = logging.getLogger("bird.data.repo")


class OtherWorldlyDropRepo:
    def __init__(self, session_factory):
        """
        session_factory: callable that returns AsyncSession, e.g. sessionmaker(...)
        """
        self._session_factory = session_factory

    async def add_other_worldly_drop(self, drop: OtherWorldlyDrop):
        async with self._session_factory() as session:
            try:
                # check existence by user_name
                stmt = select(OtherWorldlyDrop).where(OtherWorldlyDrop.user_name == drop.user_name)
                result = await session.execute(stmt)
                existing = result.scalar_one_or_none()
                if existing is None:
                    session.add(drop)
                    await session.commit()
                    logger.info(f"Added new user with userName: {drop.user_name}.")
                else:
                    logger.warning(f"User with userName: {drop.user_name} already exists. No new user added.")
            except IntegrityError as ie:
                await session.rollback()
                logger.warning(f"IntegrityError when adding drop for {drop.user_name}: {ie}")
                raise
            except Exception as ex:
                await session.rollback()
                logger.exception("An error occurred while adding OtherWorldlyDrop to the database.")
                raise

    async def get_all_other_worldly_drops(self) -> List[OtherWorldlyDrop]:
        async with self._session_factory() as session:
            try:
                stmt = select(OtherWorldlyDrop)
                result = await session.execute(stmt)
                rows = result.scalars().all()
                return rows
            except Exception as ex:
                logger.exception("An error occurred while getting all OtherWorldlyDrops from the database.")
                raise

    async def get_user_other_worldly_drops(self, user_name: str) -> List[OtherWorldlyDrop]:
        async with self._session_factory() as session:
            try:
                stmt = select(OtherWorldlyDrop).where(OtherWorldlyDrop.user_name == user_name)
                result = await session.execute(stmt)
                rows = result.scalars().all()
                return rows
            except Exception as ex:
                logger.exception("An error occurred while getting user OtherWorldlyDrops from the database.")
                raise

    async def get_all_user_other_worldly_drops(self, user_name: str) -> List[OtherWorldlyDrop]:
        async with self._session_factory() as session:
            try:
                # find user by name first to obtain the user_id
                stmt = select(OtherWorldlyDrop).where(OtherWorldlyDrop.user_name == user_name)
                result = await session.execute(stmt)
                user = result.scalar_one_or_none()
                if user is None:
                    return []

                stmt2 = select(OtherWorldlyDrop).where(OtherWorldlyDrop.user_id == user.user_id)
                result2 = await session.execute(stmt2)
                rows = result2.scalars().all()
                return rows
            except Exception as ex:
                logger.exception("An error occurred while getting all user OtherWorldlyDrops from the database.")
                raise