contents:
import os
from pathlib import Path
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from src.models.db_models import Base
import logging

logger = logging.getLogger("bird.db.engine")


def get_default_db_path() -> str:
    return os.environ.get("DATABASE_PATH", "./otherworldly.db")


def make_engine(db_path: str):
    url = f"sqlite+aiosqlite:///{db_path}"
    engine = create_async_engine(url, echo=False, future=True)
    return engine


def make_session_factory(engine):
    return sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


async def init_db(engine):
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("Database initialized / tables created.")