contents:
import logging


def configure_logging(level: str = "INFO"):
    level = getattr(logging, level.upper(), logging.INFO)
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)s %(name)s - %(message)s",
    )
    # reduce verbosity for aiohttp if desired
    logging.getLogger("aiohttp").setLevel(logging.WARNING)