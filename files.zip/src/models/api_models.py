contents:
from typing import List
from pydantic import BaseModel


class Clan(BaseModel):
    clanName: str
    score: int
    rank: int


class Skill(BaseModel):
    objective: str
    standings: List[Clan]


class TopClans(BaseModel):
    topScoreClans: List[Skill]