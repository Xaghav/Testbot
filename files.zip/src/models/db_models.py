contents:
from sqlalchemy import Column, String, Float, Integer
from sqlalchemy.orm import declarative_base
import uuid

Base = declarative_base()


class OtherWorldlyDrop(Base):
    __tablename__ = "other_worldly_drops"

    user_name = Column("user_name", String, primary_key=True, index=True)
    user_id = Column("user_id", String, nullable=False, index=True)
    share_before_run = Column("share_before_run", Float, default=0.0)
    current_share = Column("current_share", Float, default=0.0)
    total_share = Column("total_share", Float, default=0.0)
    gem_received = Column("gem_received", Integer, default=0)
    gem_to_give_back = Column("gem_to_give_back", Integer, default=0)
    current_gem_price = Column("current_gem_price", Integer, default=235)

    def __init__(
        self,
        user_name: str,
        user_id: uuid.UUID | None = None,
        share_before_run: float = 0.0,
        current_share: float = 0.0,
        total_share: float = 0.0,
        gem_received: int = 0,
        gem_to_give_back: int = 0,
        current_gem_price: int = 235,
    ):
        self.user_name = user_name
        self.user_id = str(user_id or uuid.uuid4())
        self.share_before_run = share_before_run
        self.current_share = current_share
        self.total_share = total_share
        self.gem_received = gem_received
        self.gem_to_give_back = gem_to_give_back
        self.current_gem_price = current_gem_price

    @property
    def current_share_value_in_gold(self) -> int:
        return int(self.current_gem_price * (self.current_share or 0.0))