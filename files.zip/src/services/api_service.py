contents:
import logging
from pydantic import ValidationError
from typing import Optional
from src.api.clan_cup_client import ClanCupApiClient
from src.data.models import TopClans

logger = logging.getLogger("bird.services.api")


class ApiService:
    def __init__(self, client: ClanCupApiClient):
        self._client = client

    async def get_top_clans(self) -> Optional[TopClans]:
        try:
            raw = await self._client.get_top_clans()
            # pydantic model will parse the JSON string
            top_clans = TopClans.parse_raw(raw)
            return top_clans
        except ValidationError as ve:
            logger.exception("Validation error parsing TopClans JSON")
            raise
        except Exception as ex:
            logger.exception("An error occurred while trying to fetch top clans from the API.")
            raise