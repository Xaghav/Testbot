contents:
import logging
import uuid
from src.data.models import OtherWorldlyDrop
from src.data.repository import OtherWorldlyDropRepo

logger = logging.getLogger("bird.services.app")


class AppService:
    def __init__(self, drop_repo: OtherWorldlyDropRepo):
        self._drop_repo = drop_repo

    async def run_async(self):
        try:
            new_user = uuid.uuid4()
            add_user_drop = OtherWorldlyDrop("test", new_user, 0.9, 0.2, 0.3, 0, 0)
            await self._drop_repo.add_other_worldly_drop(add_user_drop)

            drops = await self._drop_repo.get_all_user_other_worldly_drops("test")
            for drop in drops:
                logger.info(
                    f"{drop.user_name}, {drop.user_id}, {drop.share_before_run}, {drop.current_share}, {drop.total_share}, {drop.gem_received}, {drop.gem_to_give_back}, {drop.current_share_value_in_gold}"
                )

            logger.info("successfully retrieved and displayed")
        except Exception as ex:
            logger.exception("Error Adding and retrieving data")