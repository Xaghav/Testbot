contents:
import logging
from pydantic import ValidationError
from typing import Optional
from src.clients.clan_cup import ClanCupClient
from src.models.api_models import TopClans

logger = logging.getLogger("bird.services.clan")


class ClanService:
    def __init__(self, client: ClanCupClient):
        self._client = client

    async def get_top_clans(self) -> Optional[TopClans]:
        try:
            raw = await self._client.get_top_clans()
            top_clans = TopClans.parse_raw(raw)
            return top_clans
        except ValidationError:
            logger.exception("Validation error parsing TopClans JSON")
            raise
        except Exception:
            logger.exception("An error occurred while trying to fetch top clans from the API.")
            raise