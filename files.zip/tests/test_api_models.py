contents:
import json
from src.models.api_models import TopClans

SAMPLE = """
{
  "topScoreClans": [
    {
      "objective": "TopScore",
      "standings": [
        {
          "clanName": "Alpha",
          "score": 12345,
          "rank": 1
        }
      ]
    }
  ]
}
"""

def test_parse_top_clans():
    tc = TopClans.parse_raw(SAMPLE)
    assert tc.topScoreClans[0].standings[0].clanName == "Alpha"
    assert tc.topScoreClans[0].standings[0].score == 12345
    assert tc.topScoreClans[0].standings[0].rank == 1